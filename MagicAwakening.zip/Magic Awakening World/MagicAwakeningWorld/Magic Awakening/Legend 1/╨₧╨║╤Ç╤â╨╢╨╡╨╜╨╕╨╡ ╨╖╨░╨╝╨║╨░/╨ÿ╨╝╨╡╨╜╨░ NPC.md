1. **Альденар** — _Guardian Flame_
    
2. **Серинаэль** — _Serene Star_
    
3. **Таромир** — _Peace Warrior_
    
4. **Элайнар** — _Radiant Flow_
    
5. **Мирелон** — _World Echo_
    
6. **Жесарин** — _Iron Soul_
    
7. **Валеринда** — _Strong Grace_
    
8. **Лиарос** — _Voice of Truth_
    
9. **Калентара** — _Fire Bloom_
    
10. **Тэворис** — _Silent Wind_
    
11. **Олвейра** — _Ever Light_
    
12. **Родаликс** — _Stone Will_
    
13. **Санэлия** — _Sun Whisper_
    
14. **Гренморин** — _Dark Forest_
    
15. **Эвелион** — _Bringer of Hope_
    
16. **Шайрел** — _Shadow Dancer_
    
17. **Лоригрейн** — _Twilight Blade_
    
18. **Талвира** — _Ice Song_
    
19. **Демирон** — _Bloodsteel_
    
20. **Фелания** — _Flame of Beauty_
    
21. **Харомет** — _Echo of Battle_
    
22. **Илварон** — _Sky Wanderer_
    
23. **Наравель** — _River of Dreams_
    
24. **Ксарелия** — _Mystic Flame_
    
25. **Далийяра** — _Leaf in Wind_
    
26. **Браскелин** — _Shield of Thunder_
    
27. **Йалерия** — _Bright Bloom_
    
28. **Рэйналис** — _Rain Fire_
    
29. **Талондар** — _Claw of Stone_
    
30. **Солвенира** — _Healer’s Light_
    
31. **Дрекмарин** — _Sea Warden_
    
32. **Илариона** — _Sacred Voice_
    
33. **Грефалис** — _Grey Flame_
    
34. **Золемира** — _Golden Peace_
    
35. **Армодир** — _Iron Spirit_
    
36. **Невалария** — _Moon Seeker_
    
37. **Криставейн** — _Crystal Veil_