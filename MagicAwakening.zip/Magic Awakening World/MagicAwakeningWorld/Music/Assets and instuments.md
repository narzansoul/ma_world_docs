**Reference music:** 
1) deprezz - In the House, in a Heartbeat (bass version, slowed down);
2) Nectry, Antent - anywhere from here;
3) Youngblud - Abyss;
4) Antend, Kazukii - What We Had;
5) Lady Gaga - Happy Mistake;
6) suffershade - miracle;
7) Biometrix - 28 Days Later;
8) 

**Instruments:** 
2) Blooming bass (GarageBand - Bass);
3) Event Horizon (GarageBand - soundscape);
4) Ghostly Reversed Organ (-/-);
5) Stratosphere (-/-);
6) Warm Rain (-/-);
7) Alien Chorus (GB - Sound Effects);
8) Dart Bass Drive (GB - EDM Bass - raspy bow, sizzle effects);
9) Urban Grunge (-/-);
10) 

